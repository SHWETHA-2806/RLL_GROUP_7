package com.movieplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyMoviePlannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyMoviePlannerApplication.class, args);
	}

}
